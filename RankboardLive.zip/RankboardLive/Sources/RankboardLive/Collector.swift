import Foundation
import CloudKit
import CryptoKit
import RankboardLiveCore

public typealias LiveConfiguration=RankboardLiveCore.LiveConfiguration
public typealias LiveEnvelope=RankboardLiveCore.LiveEnvelope
public typealias LiveSession=RankboardLiveCore.LiveSession
public typealias LiveSDKError=RankboardLiveCore.LiveSDKError

@MainActor protocol LiveTransport {
    func accountAvailable() async throws -> Bool
    func save(_ record:CKRecord) async throws -> CKRecord
    func delete(_ id:CKRecord.ID) async throws
}
@MainActor private final class CloudTransport:LiveTransport {
    let container:CKContainer
    init(_ identifier:String) {container=CKContainer(identifier:identifier)}
    func accountAvailable()async throws -> Bool {try await container.accountStatus() == .available}
    func save(_ record:CKRecord)async throws -> CKRecord {try await container.publicCloudDatabase.save(record)}
    func delete(_ id:CKRecord.ID)async throws {_ = try await container.publicCloudDatabase.deleteRecord(withID:id)}
}

/// Add to the tracked app, using its own entitled CloudKit container.
/// Do not pass names, user content or persistent device identifiers as event labels.
@MainActor public final class RankboardCollector {
    private let configuration:LiveConfiguration
    private let transport:any LiveTransport
    private let defaults:UserDefaults
    private let ledgerKey:String
    private var record:CKRecord?
    private var session:LiveSession?
    private var heartbeat:Task<Void,Never>?
    private var writer:Task<Void,Never>?
    private var dirty=false
    private var lifecycle=0
    private var sessionGeneration=0
    public private(set) var lastError:Error?

    public convenience init(configuration:LiveConfiguration)throws {
        let config=try configuration.validated()
        self.init(configuration:config,transport:CloudTransport(config.container),defaults:.standard)
    }
    init(configuration:LiveConfiguration,transport:any LiveTransport,defaults:UserDefaults) {
        self.configuration=configuration;self.transport=transport;self.defaults=defaults
        ledgerKey="rankboard.live.records." + configuration.route
    }
    /// Signed-in iCloud sessions only. A pending start is canceled by an end or opt-out.
    public func start(setupComplete:Bool,version:String?=nil)async {
        guard session==nil || session?.endedAt != nil else{return}
        lifecycle+=1;let request=lifecycle
        if let writer {await writer.value}
        guard lifecycle==request else{return}
        do {
            guard try await transport.accountAvailable() else {throw LiveSDKError.iCloudUnavailable}
            guard lifecycle==request else{return}
            await cleanup(olderThan:Date.now.timeIntervalSince1970-86400*7)
            guard lifecycle==request else{return}
            let now=Date.now.timeIntervalSince1970,id=UUID().uuidString.lowercased()
            sessionGeneration+=1;let generation=sessionGeneration
            session=LiveSession(id:id,startedAt:now,seenAt:now,endedAt:nil,setupCompleteAtStart:setupComplete,screen:nil,mode:nil,version:version.map{String($0.prefix(64))},steps:[:],modes:[:])
            let name=SHA256.hash(data:Data((configuration.route+id).utf8)).map{String(format:"%02x",$0)}.joined()
            record=CKRecord(recordType:"RankboardSession",recordID:CKRecord.ID(recordName:name))
            var ledger=knownRecords;ledger[name]=now;knownRecords=ledger
            await flush()
            guard lifecycle==request,sessionGeneration==generation,session?.endedAt==nil,session != nil else{return}
            heartbeat=Task { [weak self] in
                while !Task.isCancelled {
                    do{try await Task.sleep(for:.seconds(60))}catch{return}
                    guard let self,self.session?.endedAt==nil,self.session != nil else{return}
                    await self.flush()
                }
            }
        } catch {if lifecycle==request {lastError=error}}
    }
    public func screen(_ name:String) {guard session != nil,session?.endedAt==nil else{return};session?.screen=String(name.prefix(64));dirty=true}
    public func mode(_ name:String) {
        guard var value=session,value.endedAt==nil else{return}
        let key=String(name.prefix(64));value.mode=key
        if value.modes.count<24 || value.modes[key] != nil {value.modes[key]=min(100000,(value.modes[key] ?? 0)+1)}
        session=value;dirty=true
    }
    public func step(_ name:String) {
        guard session != nil,session?.endedAt==nil else{return}
        let key=String(name.prefix(64))
        if (session?.steps.count ?? 0)<24 || session?.steps[key] != nil {session?.steps[key]=1;dirty=true}
    }
    public func end()async {
        lifecycle+=1;heartbeat?.cancel();heartbeat=nil
        guard session != nil else{return}
        session?.endedAt=Date.now.timeIntervalSince1970;dirty=true
        await flush()
    }
    /// All callers await the same serialized writer. Retry writes replace one record.
    public func flush()async {
        guard session != nil,record != nil else{return}
        dirty=true
        if let writer {await writer.value;return}
        let task=Task {await self.writeLoop()};writer=task
        await task.value
    }
    private func writeLoop()async {
        defer{writer=nil}
        while dirty {
            dirty=false
            guard var value=session,let current=record,let recipient=Data(base64Encoded:configuration.publicKey) else{return}
            let generation=sessionGeneration
            value.seenAt=max(Date.now.timeIntervalSince1970,value.endedAt ?? 0);session=value
            do {
                let envelope=try LiveEnvelope.seal(JSONEncoder().encode(value),recipient:recipient,route:configuration.route)
                current["route"]=configuration.route as CKRecordValue
                current["startedAt"]=value.startedAt as CKRecordValue
                current["ephemeralKey"]=envelope.ephemeralKey as CKRecordValue
                current["ciphertext"]=envelope.ciphertext as CKRecordValue
                let saved=try await transport.save(current)
                if sessionGeneration != generation || session==nil {
                    // An old in-flight result must never attach itself to a new session.
                    try await remove(saved.recordID)
                } else {
                    record=saved;lastError=nil
                    if value.endedAt != nil && !dirty {session=nil;record=nil}
                }
            } catch {lastError=error;return}
        }
    }
    /// Delete sessions remembered on this installation, including completed sessions.
    /// Persist the app's opt-out preference and stop calling start until opt-in.
    public func optOut()async {
        let ids=Array(knownRecords.keys)
        lifecycle+=1;sessionGeneration+=1;heartbeat?.cancel();heartbeat=nil
        session=nil;record=nil;dirty=false
        if let writer {await writer.value}
        for name in ids {do{try await remove(CKRecord.ID(recordName:name))}catch{lastError=error}}
    }
    private var knownRecords:[String:Double] {
        get{defaults.dictionary(forKey:ledgerKey) as? [String:Double] ?? [:]}
        set{defaults.set(newValue,forKey:ledgerKey)}
    }
    private func cleanup(olderThan cutoff:Double)async {
        let ids=knownRecords.filter{$0.value<cutoff}.map(\.key)
        for name in ids {
            do{try await remove(CKRecord.ID(recordName:name))}catch{lastError=error}
        }
    }
    private func remove(_ id:CKRecord.ID)async throws {
        do{try await transport.delete(id)}catch let error as CKError where error.code == .unknownItem {}
        var ledger=knownRecords;ledger.removeValue(forKey:id.recordName);knownRecords=ledger
    }
}
