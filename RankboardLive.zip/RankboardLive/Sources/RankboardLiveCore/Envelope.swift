import Foundation
import CryptoKit

/// Only ciphertext and routing timestamps belong in the public CloudKit record.
public struct LiveEnvelope: Codable, Sendable {
    public let ephemeralKey:String
    public let ciphertext:String
    public init(ephemeralKey:String,ciphertext:String) {self.ephemeralKey=ephemeralKey;self.ciphertext=ciphertext}
    public static func seal(_ data:Data, recipient:Data, route:String) throws -> LiveEnvelope {
        let publicKey=try P256.KeyAgreement.PublicKey(x963Representation:recipient)
        let ephemeral=P256.KeyAgreement.PrivateKey()
        let secret=try ephemeral.sharedSecretFromKeyAgreement(with:publicKey)
        let key=secret.hkdfDerivedSymmetricKey(using:SHA256.self,salt:Data("rankboard-live-v1".utf8),sharedInfo:Data(route.utf8),outputByteCount:32)
        let box=try AES.GCM.seal(data,using:key,authenticating:Data(route.utf8))
        guard let combined=box.combined else { throw LiveSDKError.invalidConfiguration }
        return LiveEnvelope(ephemeralKey:ephemeral.publicKey.x963Representation.base64EncodedString(),ciphertext:combined.base64EncodedString())
    }
    public func open(privateKey:Data, route:String) throws -> Data {
        guard let publicData=Data(base64Encoded:ephemeralKey),let combined=Data(base64Encoded:ciphertext),combined.count<=32768 else {throw LiveSDKError.invalidConfiguration}
        let privateKey=try P256.KeyAgreement.PrivateKey(rawRepresentation:privateKey)
        let publicKey=try P256.KeyAgreement.PublicKey(x963Representation:publicData)
        let secret=try privateKey.sharedSecretFromKeyAgreement(with:publicKey)
        let key=secret.hkdfDerivedSymmetricKey(using:SHA256.self,salt:Data("rankboard-live-v1".utf8),sharedInfo:Data(route.utf8),outputByteCount:32)
        return try AES.GCM.open(AES.GCM.SealedBox(combined:combined),using:key,authenticating:Data(route.utf8))
    }
}

public struct LiveConfiguration: Codable, Sendable {
    public let container:String
    public let route:String
    public let publicKey:String
    public init(container:String,route:String,publicKey:String) throws {
        guard container.range(of:"^iCloud\\.[A-Za-z0-9.-]{3,180}$",options:.regularExpression) != nil,
              route.range(of:"^[a-f0-9]{64}$",options:.regularExpression) != nil,
              let key=Data(base64Encoded:publicKey), (try? P256.KeyAgreement.PublicKey(x963Representation:key)) != nil else { throw LiveSDKError.invalidConfiguration }
        self.container=container;self.route=route;self.publicKey=publicKey
    }
    public func validated() throws -> LiveConfiguration { try Self(container:container,route:route,publicKey:publicKey) }
}

public struct LiveSession: Codable, Sendable, Equatable {
    public var id:String
    public var startedAt:Double
    public var seenAt:Double
    public var endedAt:Double?
    public var setupCompleteAtStart:Bool
    public var screen:String?
    public var mode:String?
    public var version:String?
    public var steps:[String:Int]
    public var modes:[String:Int]
    public init(id:String,startedAt:Double,seenAt:Double,endedAt:Double?,setupCompleteAtStart:Bool,screen:String?,mode:String?,version:String?,steps:[String:Int],modes:[String:Int]) {
        self.id=id;self.startedAt=startedAt;self.seenAt=seenAt;self.endedAt=endedAt;self.setupCompleteAtStart=setupCompleteAtStart
        self.screen=screen;self.mode=mode;self.version=version;self.steps=steps;self.modes=modes
    }
    public func validated(now:Date) -> Bool {
        let maxTime=now.timeIntervalSince1970+300
        return UUID(uuidString:id) != nil && startedAt.isFinite && seenAt.isFinite && startedAt>0 && startedAt<=maxTime && seenAt>=startedAt && seenAt<=maxTime
            && (endedAt.map{$0.isFinite && $0>=startedAt && $0<=seenAt} ?? true)
            && [screen,mode,version].allSatisfy{$0.map{$0.count<=64} ?? true}
            && steps.count<=24 && modes.count<=24 && (Array(steps)+Array(modes)).allSatisfy{$0.key.count<=64 && $0.value>=0 && $0.value<=100000}
    }
}
public enum LiveSDKError: Error { case invalidConfiguration, iCloudUnavailable }
