// swift-tools-version: 6.0
import PackageDescription
let package = Package(name:"RankboardLiveSDK",platforms:[.iOS(.v18),.macOS(.v14)],products:[
    .library(name:"RankboardLive",targets:["RankboardLive"]),
    .library(name:"RankboardLiveCore",targets:["RankboardLiveCore"])
],targets:[
    .target(name:"RankboardLiveCore"),
    .target(name:"RankboardLive",dependencies:["RankboardLiveCore"],resources:[.process("PrivacyInfo.xcprivacy")]),
    .testTarget(name:"RankboardLiveTests",dependencies:["RankboardLive"])
])
