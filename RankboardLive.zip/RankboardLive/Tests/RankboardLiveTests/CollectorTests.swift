import XCTest
import CloudKit
import CryptoKit
@testable import RankboardLive

@MainActor private final class DelayedTransport:LiveTransport {
    var pauseSave=false,pauseAccount=false
    var saveGate:CheckedContinuation<Void,Never>?
    var accountGate:CheckedContinuation<Void,Never>?
    var writes:[(String,LiveEnvelope)]=[]
    var deleted:Set<String>=[]
    var inFlight=0,maxInFlight=0
    func accountAvailable()async throws -> Bool {
        if pauseAccount {await withCheckedContinuation{accountGate=$0}}
        return true
    }
    func save(_ record:CKRecord)async throws -> CKRecord {
        writes.append((record.recordID.recordName,.init(ephemeralKey:record["ephemeralKey"] as! String,ciphertext:record["ciphertext"] as! String)))
        inFlight+=1;maxInFlight=max(maxInFlight,inFlight);defer{inFlight-=1}
        if pauseSave {pauseSave=false;await withCheckedContinuation{saveGate=$0}}
        return record
    }
    func delete(_ id:CKRecord.ID)async throws {deleted.insert(id.recordName)}
}

final class CollectorTests:XCTestCase {
    @MainActor private func fixture()throws -> (RankboardCollector,DelayedTransport,P256.KeyAgreement.PrivateKey,LiveConfiguration,UserDefaults) {
        let key=P256.KeyAgreement.PrivateKey(),transport=DelayedTransport()
        let config=try LiveConfiguration(container:"iCloud.com.example.game",route:String(repeating:"b",count:64),publicKey:key.publicKey.x963Representation.base64EncodedString())
        let defaults=UserDefaults(suiteName:"RankboardCollectorTests."+UUID().uuidString)!
        return (RankboardCollector(configuration:config,transport:transport,defaults:defaults),transport,key,config,defaults)
    }
    @MainActor private func waitUntil(_ condition:()->Bool)async throws {
        for _ in 0..<10000 {if condition(){return};await Task.yield()}
        throw NSError(domain:"CollectorTests",code:1,userInfo:[NSLocalizedDescriptionKey:"Async test gate was not reached"])
    }
    private func decode(_ envelope:LiveEnvelope,key:P256.KeyAgreement.PrivateKey,route:String)throws -> LiveSession {
        try JSONDecoder().decode(LiveSession.self,from:envelope.open(privateKey:key.rawRepresentation,route:route))
    }
    @MainActor func testForegroundRestartWaitsForEndedWriteAndCreatesNewSession()async throws {
        let (collector,t,key,config,_)=try fixture();t.pauseSave=true
        let start=Task{await collector.start(setupComplete:false)}
        try await waitUntil{t.saveGate != nil}
        let end=Task{await collector.end()};await Task.yield()
        let restart=Task{await collector.start(setupComplete:true)};await Task.yield()
        t.saveGate?.resume();t.saveGate=nil
        await start.value;await end.value;await restart.value
        XCTAssertEqual(t.maxInFlight,1)
        XCTAssertGreaterThanOrEqual(t.writes.count,3)
        XCTAssertEqual(t.writes[0].0,t.writes[1].0)
        XCTAssertNotEqual(t.writes[0].0,t.writes.last!.0)
        XCTAssertNotNil(try decode(t.writes[1].1,key:key,route:config.route).endedAt)
        XCTAssertNil(try decode(t.writes.last!.1,key:key,route:config.route).endedAt)
        XCTAssertTrue(try decode(t.writes.last!.1,key:key,route:config.route).setupCompleteAtStart)
        await collector.optOut()
    }
    @MainActor func testOptOutDuringWriteDoesNotDeleteNewOptInSession()async throws {
        let (collector,t,key,config,_)=try fixture();t.pauseSave=true
        let start=Task{await collector.start(setupComplete:false)}
        try await waitUntil{t.saveGate != nil}
        let optOut=Task{await collector.optOut()};await Task.yield()
        let optIn=Task{await collector.start(setupComplete:true)};await Task.yield()
        t.saveGate?.resume();t.saveGate=nil
        await start.value;await optOut.value;await optIn.value
        XCTAssertEqual(t.writes.count,2)
        XCTAssertTrue(t.deleted.contains(t.writes[0].0))
        XCTAssertFalse(t.deleted.contains(t.writes[1].0))
        XCTAssertNil(try decode(t.writes[1].1,key:key,route:config.route).endedAt)
        await collector.optOut()
    }
    @MainActor func testEndDuringAccountCheckDoesNotStartSession()async throws {
        let (collector,t,_,_,_)=try fixture();t.pauseAccount=true
        let start=Task{await collector.start(setupComplete:false)}
        try await waitUntil{t.accountGate != nil}
        await collector.end();t.accountGate?.resume();t.accountGate=nil
        await start.value
        XCTAssertTrue(t.writes.isEmpty)
    }
    @MainActor func testOptOutRemovesEndedSessionsRememberedAcrossCollectorInstances()async throws {
        let (collector,t,_,config,defaults)=try fixture()
        await collector.start(setupComplete:true);await collector.end()
        let endedID=t.writes[0].0
        let next=RankboardCollector(configuration:config,transport:t,defaults:defaults)
        await next.optOut()
        XCTAssertTrue(t.deleted.contains(endedID))
        XCTAssertEqual(defaults.dictionary(forKey:"rankboard.live.records."+config.route)?.count,0)
    }
}
