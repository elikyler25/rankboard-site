import XCTest
import CryptoKit
@testable import RankboardLive

final class EnvelopeTests:XCTestCase {
    func testOwnerCanDecryptAndWrongOwnerOrRouteCannot() throws {
        let owner=P256.KeyAgreement.PrivateKey(),other=P256.KeyAgreement.PrivateKey()
        let value=Data("session without personal content".utf8)
        let e=try LiveEnvelope.seal(value,recipient:owner.publicKey.x963Representation,route:String(repeating:"a",count:64))
        XCTAssertEqual(try e.open(privateKey:owner.rawRepresentation,route:String(repeating:"a",count:64)),value)
        XCTAssertThrowsError(try e.open(privateKey:other.rawRepresentation,route:String(repeating:"a",count:64)))
        XCTAssertThrowsError(try e.open(privateKey:owner.rawRepresentation,route:String(repeating:"b",count:64)))
        XCTAssertFalse(e.ciphertext.contains("personal"))
    }
    func testTamperingIsRejected() throws {
        let key=P256.KeyAgreement.PrivateKey()
        let e=try LiveEnvelope.seal(Data("original".utf8),recipient:key.publicKey.x963Representation,route:"route")
        var bytes=Data(base64Encoded:e.ciphertext)!;bytes[bytes.count-1] ^= 1
        let bad=LiveEnvelope(ephemeralKey:e.ephemeralKey,ciphertext:bytes.base64EncodedString())
        XCTAssertThrowsError(try bad.open(privateKey:key.rawRepresentation,route:"route"))
    }
    func testConfigurationRejectsUntrustedContainerAndBadKeys() throws {
        let key=P256.KeyAgreement.PrivateKey().publicKey.x963Representation.base64EncodedString()
        XCTAssertThrowsError(try LiveConfiguration(container:"https://example.com",route:String(repeating:"a",count:64),publicKey:key))
        XCTAssertThrowsError(try LiveConfiguration(container:"iCloud.com.example.game",route:"bad",publicKey:key))
        XCTAssertNoThrow(try LiveConfiguration(container:"iCloud.com.example.game",route:String(repeating:"a",count:64),publicKey:key))
    }
}
