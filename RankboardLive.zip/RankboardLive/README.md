# Rankboard Live — Apple-only integration

This native Swift package sends encrypted foreground-session records to **your tracked app’s own CloudKit container**. Rankboard reads them directly from Apple using a CloudKit API token and decrypts on the owner’s phone. No Rankboard server receives events or purchase receipts.

Verification: native writes, recipient decryption, duplicate-write handling and session-end delivery passed on a signed-in physical iPhone in Development. The matching schema is deployed to Production. Seven automated tests cover encryption, configuration, foreground restart, in-flight opt-out and remembered-session deletion. Production transport, cross-developer web-service queries and cross-device key recovery require integration-specific verification.

## Coverage

CloudKit writes require the player to be signed into iCloud. This does not measure every installation or unique person. Apple associates public records with the writing iCloud account. The payload contains a fresh random foreground-session ID and bounded screen/mode/setup names, not names, emails or persistent device IDs. CloudKit record metadata and routing timestamps remain visible in the public database. Disclose these facts in the tracked app’s privacy policy and App Store privacy answers.

## Container setup

1. Enable CloudKit in the tracked app and select a container owned by its developer team. Do not add the Rankboard container to another developer’s app.
2. In CloudKit Console create public record type `RankboardSession`:

| Field | Type | Index |
| --- | --- | --- |
| route | String | Queryable |
| startedAt | Double | Queryable |
| ephemeralKey | String | None |
| ciphertext | String | None |

3. Grant Everyone read, Authenticated create, and Creator write permissions. Each installation updates its own random session record. Keep default creator-only updates; never permit global writes to other users’ records.
4. Enable CloudKit web services and create an API token allowing public queries. Enter the container and token in Rankboard → Live → Setup. The API token stays in Keychain and is not included in exported analytics or the SDK configuration.
5. Test with Development selected in Rankboard. The tracked app’s provisioning determines its CloudKit environment; the settings must match. Deploy schema, indexes and permissions to Production before a release.
6. Maintain container-wide retention. The SDK remembers this installation’s record names in UserDefaults and attempts to delete those older than seven days on the next session start. Opt-out attempts deletion of all its remembered records, including ended sessions. Failed deletions stay in the local ledger for retry. Offline, uninstalled or inactive installations cannot perform cleanup; the container owner must maintain a retention process for those records. Inactive sessions are filtered after 120 seconds; that is not physical deletion. Container storage/query quotas belong to the tracked app’s developer.

## App hooks

Add this local package to the tracked app and import `RankboardLive`. Decode the JSON configuration copied from Rankboard into `LiveConfiguration`, then validate it through the collector initializer:

```swift
let config = try JSONDecoder().decode(LiveConfiguration.self, from: configurationJSON)
let collector = try RankboardCollector(configuration: config)

// On foreground entry, only if the player has not opted out:
await collector.start(setupComplete: hasFinishedSetup, version: appVersion)
collector.screen("home")
await collector.flush()

// Named product events, with no personal content:
collector.step("onboarding_done")
collector.mode("zen")
collector.screen("play_zen")
await collector.flush()

// On leaving the foreground (allow background time for the write):
await collector.end()

// On an explicit analytics opt-out (removes remembered sessions on this installation):
await collector.optOut()
// Persist that preference and do not call start again unless the user opts in.
```

One record per session prevents duplicate counting on write retries. A heartbeat updates it every 60 seconds. Payload encryption uses ephemeral P-256 key agreement, HKDF-SHA256 and AES-GCM, with the route authenticated. Only the recipient private key decrypts the payload. Rankboard stores that key in synchronizable Keychain; it requires an end-to-end recovery check on a second device with iCloud Keychain enabled. Do not put the recipient private key or a CloudKit server-to-server signing key in the tracked app.

The dashboard limits a refresh to 2,000 session records and labels truncated/undecryptable results as partial. It ignores CloudKit creator identities. Rankboard persists a report snapshot in private SwiftData/iCloud and can export it to Files; it does not persist decrypted session IDs.

The collector includes a privacy manifest for UserDefaults use, Product Interaction and pseudonymous User ID metadata, linked for Analytics and not used for advertising tracking. Review your host app’s App Privacy answers and policy before release. Rankboard itself links only the read-only `RankboardLiveCore` product, so it does not run this collector or send telemetry about Rankboard users.

## Verification required before shipping

- A development-device session appears in Rankboard using the real CloudKit token and query indexes.
- A heartbeat updates one record; an ended session stops appearing active.
- An account signed out of iCloud reports no events; the UI still states limited coverage.
- Opt-out during an in-flight write removes the current record and prevents future starts through the app’s saved preference.
- A different developer’s container works through public web-service queries without granting Rankboard native entitlements to that container.
- Two owner devices decrypt through iCloud Keychain; key changes do not silently make deployed integrations unreadable.
- Production schema, retention and App Store privacy answers match actual behavior.

Apple references: [CloudKit account requirements](https://developer.apple.com/documentation/cloudkit/ckcontainer), [CloudKit web-service queries](https://developer.apple.com/library/archive/documentation/DataManagement/Conceptual/CloudKitWebServicesReference/QueryingRecords.html), [public database](https://developer.apple.com/documentation/cloudkit/ckcontainer/publicclouddatabase).
